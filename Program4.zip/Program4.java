//Create an CBSC Board Percentage Claculator (Java Programming Excercise 1)

import java.util.Scanner;

public class Program4{
    public static void main(String [] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter The 5 Subjact Marks : ");
        System.out.println("Enter The Subjact 1 Marks : ");
        float sub1 = sc.nextFloat();
        System.out.println("Enter The Subjact 2 Marks : ");
        float sub2 = sc.nextFloat();
        System.out.println("Enter The Subjact 3 Marks : ");
        float sub3 = sc.nextFloat();
        System.out.println("Enter The Subjact 4 Marks : ");
        float sub4 = sc.nextFloat();
        System.out.println("Enter The Subjact 5 Marks : ");
        float sub5 = sc.nextFloat();

        System.out.println("This is The Total of 5 Subjacts");
        float Total = sub1 + sub2 + sub3 + sub4 + sub5;
        System.out.println(Total);

        System.out.println("This is The Percentage : ");
        float percentage = (Total*100)/500;
        System.out.println(percentage);
    }
}