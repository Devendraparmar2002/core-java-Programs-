//This is The Hello World Program

public class Program1{
    public static void main(String [] args){
        System.out.println("Hello! World");
    }
}

/*
OUTPUT:
Hello! World
*/