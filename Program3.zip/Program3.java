//This is the Java add Three Numbers Program get Input From The User.

import java.util.Scanner;

public class Program3{
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);

        System.out.println("Add Three Numbers : ");
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        int num3 = sc.nextInt();
        int sum = num1 + num2 + num3;
        System.out.println("This is The Sum of Three Number :");
        System.out.println(sum); 
    }
}

/*
OUTPUT:
Add Three Numbers : 
10
20
30
This is The Sum of Three Number : 
60
*/